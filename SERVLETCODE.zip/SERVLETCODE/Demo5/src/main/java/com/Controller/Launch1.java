package com.Controller;

import java.io.IOException;

import com.Dao.EmployeeDao;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/add")
public class Launch1 extends HttpServlet {
	
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		String username = req.getParameter("username");
		String project = req.getParameter("project");
		
		
		EmployeeDao eDao = new EmployeeDao();
		eDao.insertEmplopyee(Integer.valueOf(id), username, project);
		
		
		resp.sendRedirect("index.html");
	}

}

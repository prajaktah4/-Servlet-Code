package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.ConnectionFactory.ConnectionFactory;

public class EmployeeDao {
	
	public void insertEmplopyee(int id, String name, String project)
	{
		try
		{
			Connection con = ConnectionFactory.getCon();
			String sql = "insert into employee values(?,?,?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setString(3, project);
			
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		
		
	}
	
	
	
	
	
	
	
	
	

}

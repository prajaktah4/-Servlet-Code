package com.Controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/register")
public class Launch1 extends HttpServlet {
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name = req.getParameter("username");
		String pass = req.getParameter("password");
		String email = req.getParameter("email");
		
		HttpSession s = req.getSession();
		s.setAttribute("name", name);
		s.setAttribute("pass", pass);
		s.setAttribute("email", email);
		
		//resp.sendRedirect("show.jsp");
		resp.sendRedirect("show1.jsp");
		
	}

}

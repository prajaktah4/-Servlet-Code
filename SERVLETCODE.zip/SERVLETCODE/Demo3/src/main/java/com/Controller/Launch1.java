package com.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//@WebServlet(urlPatterns = {"/xyz", "/pqr"}, name ="s1")
//@WebServlet(value = "/xyz")
@WebServlet("/xyz")
public class Launch1 extends HttpServlet
{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name = req.getParameter("username");
		
	
		
		PrintWriter out = resp.getWriter();
		
		
		out.print("<h1> Entered Name is "+name+"</h1>");
		out.print("<a href='index.html' target='_blank'>Home</a>");
		
	}
}

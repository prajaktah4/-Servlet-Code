package com.Controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/info")
public class Launch1 extends HttpServlet {
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name = req.getParameter("username");
		String project = req.getParameter("project");
		String skill = req.getParameter("skill");
		
		
		HttpSession s = req.getSession();
		s.setAttribute("n", name);
		s.setAttribute("p", project);
		s.setAttribute("s", skill);
		
		resp.sendRedirect("show.jsp");
	}

}

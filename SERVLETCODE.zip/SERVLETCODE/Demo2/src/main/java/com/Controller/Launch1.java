package com.Controller;

import java.io.IOException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Launch1 extends HttpServlet{
	
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		System.out.println("In Launch1");
		
		ServletContext cxt = getServletContext();
		String password = cxt.getInitParameter("password");
		System.out.println(password);
		
		
		ServletConfig cfg = getServletConfig();
		String age = cfg.getInitParameter("age");
		System.out.println(age);
		
		resp.sendRedirect("index.html");
		
	}

}

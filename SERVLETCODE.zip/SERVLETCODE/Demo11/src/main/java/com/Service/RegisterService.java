package com.Service;

import com.Dao.UserInfoDao;

public class RegisterService {
	
	public void insertUser(String username, String pass, String email)
	{
		System.out.println("Emial sent "+email);
		
		UserInfoDao uDao = new UserInfoDao();
		uDao.saveUser(username, pass, email);
	}

}

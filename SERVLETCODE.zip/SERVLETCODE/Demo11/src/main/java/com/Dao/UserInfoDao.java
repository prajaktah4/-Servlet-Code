package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.ConnectionFactory.ConnectionFactory;

public class UserInfoDao {
	
	
	public void saveUser(String name, String pass, String email)
	{
		try
		{
			String sql ="insert into userinfo values(?,?,?)";
			
			Connection con = ConnectionFactory.getCon();
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, pass);
			ps.setString(3, email);
			
			ps.executeUpdate();
			
		}
		
		catch (Exception e) 
		{
			System.out.println(e);
		}
	}

}

package com.Temp;

public class Demo {
	
	public int add(int a, int b)
	{
		return a+b;
	}

}
